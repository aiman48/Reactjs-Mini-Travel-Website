import React from 'react';
import { Link } from 'react-router-dom';
import Destination from "../components/Destination";
import Footer from "../components/Footer";
import Hero from "../components/Hero";
import Navbar from "../components/Navbar";
import Trip from "../components/Trip";

function Home() {
    return (
        <>
            <Navbar />
            <Hero
                cName="hero"
                heroImg="src/assets/47ecc0e5-f12a-4dc0-b489-79e31d1b4a6f.jpg"
                title="Your Journey Your Story"
                text="Discover your dream destination: choose your favorite travel spot today!"
                buttonText="Travel Plan"
                url="/"
                btnClass="show"
            />
            <Destination/>
            <Link to="/service">Travel Plan</Link> {/* Link to the Service page */}
            <Trip/>
            <Footer/>
        </>
    );
}

export default Home;
