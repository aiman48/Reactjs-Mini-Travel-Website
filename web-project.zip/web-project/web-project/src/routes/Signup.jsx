import React, { useState } from 'react';
import './SignUp.css';

const Signup = ({ onRegister }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleOpen = () => {
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleRegister = (e) => {
    e.preventDefault();
    if (email && password) {
      // Trigger the onRegister function passed from parent component
      onRegister({ email, password });
      handleClose();
    } else {
      alert('Please fill in all fields.');
    }
  };

  return (
    <div className="signup-container">
      <button onClick={handleOpen} className="signup-button">
        Sign Up
      </button>
      {isOpen && (
        <div className="signup-form">
          <h2>Sign Up</h2>
          <form onSubmit={handleRegister}>
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              required
            />
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
              required
            />
            <button type="submit" >Register</button>
          </form>
          <button className="close-button" onClick={handleClose}>
            X
          </button>
        </div>
      )}
    </div>
  );
};

export default Signup;
