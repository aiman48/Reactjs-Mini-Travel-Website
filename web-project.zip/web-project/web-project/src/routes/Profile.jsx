import React from 'react';
import "./Profile.css";

const Profile = ({ email, onLogout }) => {
  const handleLogout = () => {
    localStorage.removeItem('user');
    onLogout();
  };

  return (
    <div>
      <h2>Welcome, {email}!</h2>
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Profile;
