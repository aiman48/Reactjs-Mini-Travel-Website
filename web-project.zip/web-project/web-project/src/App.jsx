import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './routes/Home';
import Service from './routes/Service';
import Contact from './routes/Contact';
import About from './routes/About';
import Signup from './routes/Signup';
import Login from './routes/Login';
import Navbar from './components/Navbar';

function App() {
  const handleRegister = (userData) => {
    // Handle user registration logic here
    console.log('User registered:', userData);
  };

  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/service" element={<Service />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/signup" element={<Signup onRegister={handleRegister} />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </div>
  );
}

export default App;
