import React from 'react';
import './ContactFormStyles.css';

function ContactForm() {
  const handleSendMessage = () => {
    // Here you can implement the logic to send the message
    // For this example, we'll just show an alert indicating that the message has been sent
    alert('Message sent successfully!');
  };

  return (
    <div className="form-wrapper">
      <div className="form-container">
        <h1>Send message to us!</h1>
        <form>
          <input placeholder="Name" />
          <input placeholder="Email" />
          <input placeholder="Subject" />
          <textarea placeholder="Message" rows="4"></textarea>
          <button type="button" onClick={handleSendMessage}>Send Message</button>
        </form>
      </div>
    </div>
  );
}

export default ContactForm;
