import React from 'react';
import { Link } from 'react-router-dom'; // Import Link component
import "./HeroStyles.css";

function Hero(props) {
    return (
        <div className={props.cName}>
            <img src={props.heroImg} alt="Hero" />
            <div className="hero-text">
                <h1>{props.title}</h1>
                {props.text && <p>{props.text}</p>}
                {props.buttonText && (
                    <Link to={props.url} className={props.btnClass}> {/* Use Link component */}
                        {props.buttonText}
                    </Link>
                )}
            </div>
        </div>
    );
}

export default Hero;
