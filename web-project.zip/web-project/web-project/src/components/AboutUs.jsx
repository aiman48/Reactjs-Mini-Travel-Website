import "./AboutUsStyles.css";

function AboutUs(){
    return(
        <div className="about-container">
            <h1>Our History</h1>
            <p> From our early days of organizing bespoke trips to today’s comprehensive travel solutions, Odyssey has always been at the forefront of innovation. We have consistently embraced new technologies and trends to enhance our services, making travel planning seamless and enjoyable. Our commitment to excellence has earned us the trust and loyalty of our customers, and we continue to expand our offerings to cater to the evolving needs of modern travelers.</p>

            <h1>Our Mission</h1>
            <p>At Odyssey, our mission is to inspire and empower people to explore the world with curiosity and confidence. We strive to make travel accessible, enriching, and sustainable by providing personalized experiences and exceptional service. Our goal is to connect travelers with authentic experiences that foster cultural understanding and personal growth.</p>

            <h1>Our Vision</h1>
            <p>Our vision at Odyssey is to be the world’s most trusted and innovative travel companion. We envision a future where every journey is a transformative adventure, where barriers to travel are removed, and where our platform becomes synonymous with excellence in travel planning and experiences</p>



        </div>
    )
}
export default AboutUs;