import DestinationData from "./DestinationData";

import "./DestinationStyles.css"
const Destination = ()=>{
    return(
        <div className="destination">
            <h1>Popular Destinations</h1>
            <p> Tours give you the oppurtuninty to see alot, with a time frame</p>

            <DestinationData 
             className="first-des"
              heading="The London Eye"
              text="The London Eye, an iconic symbol of the city, offers a
              breathtaking 360-degree panorama of London’s skyline. 
              Standing at 135 meters (443 feet) high, it provides views
             extending up to 40 kilometers (25 miles) on a clear day, 
             reaching as far as Windsor Castle. During the 30-minute rotation, 
             you can spot historic landmarks like the Houses of Parliament, St 
             Paul’s Cathedral, and modern structures such as 'the Gherkin.' Each
             of the 32 glass-walled pods allows for unobstructed views and is equipped
             with interactive screens to enhance the experience. Whether visited by day
             or night, the London Eye delivers a serene and unforgettable perspective of the city"
             img1="https://www.britain-magazine.com/wp-content/uploads/weblondoneye.jpg"
             img2="https://media.cntraveler.com/photos/58c1782b5526e51b7d557df2/1:1/w_2496,h_2496,c_limit/London-Eye-Red-cr-Doug-Peters.jpg"
            />

            <DestinationData 
              className="first-des-reverse"
              heading="London Bridge"
              text="London Bridge, an iconic symbol of the city's 
               history and resilience, spans the majestic River Thames
                in London, England. Its rich heritage dates back centuries,
                with various iterations standing proudly in the heart of the
                city. The current structure, a modern marvel of engineering,
                is a testament to London's ability to blend tradition with 
                innovation. As a bustling thoroughfare, London Bridge not only 
                connects the north and south banks of the river but also serves
                as a focal point for both locals and tourists alike. With its
                breathtaking views of the city skyline and the river below, London
                Bridge remains a timeless landmark, captivating visitors with its
                charm and history."

             img1="https://images.pexels.com/photos/1427578/pexels-photo-1427578.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
             img2="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/07/8d/60/eb/tower-bridge.jpg?w=1200&h=1200&s=1"
            />

            </div>
        
    )
}  
export default Destination;