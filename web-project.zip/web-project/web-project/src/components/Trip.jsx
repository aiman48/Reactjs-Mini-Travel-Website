import "./TripStyles.css"
import TripData from "./TripData";

function Trip(){
    return(
        <div className="trip"> 
         <h1> Recent Trips</h1>
         <p> You can discover unique destinations using Google Maps</p>
        
        <div className="tripcard">
            <TripData
              image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxIkh_z74UClu_3THwJuYo1JHnoVWmSto5XOZJ4NdwIw&s"
              heading="Trip in Indonesia"
              text="ndonesia offers a captivating journey with its diverse landscapes,
                vibrant culture, and delicious cuisine. Explore Bali's pristine beaches, 
                Jakarta's bustling markets, and ancient temples like Borobudur. From lush 
                jungles to volcanic landscapes, each moment promises unforgettable experiences."
            />
            <TripData
              image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrk6PZH_5wy0jKfU1rllnAJkPklDlCwUfhPGteY9cJhQ&s"
              heading="Trip in Pakistan"
              text="Embarking on a trip to Pakistan unveils a
               tapestry of breathtaking landscapes, rich history, and
                warm hospitality. From the majestic mountains of the
                Karakoram Range to the ancient ruins of Mohenjo-Daro,
                the country is a treasure trove of wonders waiting to be 
                explored. Delve into the bustling streets of Lahore, where 
                the aroma of spicy cuisine fills the air, or wander through
                the serene valleys of Swat, where emerald-green meadows meet cascading waterfalls."
            />

            <TripData
              image="https://theworldpursuit.com/wp-content/uploads/2021/10/Grindelwald-switzerland.jpeg"
              heading="Trip in Switzerland"
              text="Embarking on a trip to Switzerland is like stepping into a
               postcard-perfect wonderland, where snow-capped peaks, pristine lakes, 
               and charming villages await. Explore the picturesque streets of Lucerne, 
               where medieval architecture meets modern charm, or indulge in chocolate delights 
               in the vibrant city of Zurich. Traverse the scenic Swiss Alps, where opportunities 
               for skiing, hiking, and breathtaking panoramic views abound. Cruise along the tranquil 
               waters of Lake Geneva, marveling at the majestic Alps reflected in its shimmering surface."
            />
        </div>
        </div>
    )
}
export default Trip;